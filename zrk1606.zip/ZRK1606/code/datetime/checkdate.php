<?php

if (checkdate(3, 35, 2016)) {
    print "March 35, 2016 is OK";
}
if (checkdate(2, 29, 2016)) {
    print "February 29, 2016 is OK";
}
if (checkdate(2, 29, 2017)) {
    print "February 29, 2017 is OK";
}
