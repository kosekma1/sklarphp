<?php

$_POST['yr'] = '2016';
$_POST['mo'] = '5';
$_POST['dy'] = '12';
$_POST['hr'] = '4';
$_POST['mn'] = '15';
