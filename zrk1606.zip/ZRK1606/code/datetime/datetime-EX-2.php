<?php
$d = new DateTime();
print $d->format('m/d/y');