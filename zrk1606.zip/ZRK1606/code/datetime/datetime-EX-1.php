<?php
$d = new DateTime();
print 'It is now: ';
print $d->format('r');
print "\n";