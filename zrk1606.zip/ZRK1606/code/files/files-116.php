<?php
$fh = fopen('c:/windows/system32/settings.txt','rb');