<?php

$_POST['user'] = '../etc/passwd';
