<?php
$_SERVER['argv'][1] = '10040';
