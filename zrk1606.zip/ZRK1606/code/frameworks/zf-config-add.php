            'Application\Controller\Menu' => 'Application\Controller\MenuController'
