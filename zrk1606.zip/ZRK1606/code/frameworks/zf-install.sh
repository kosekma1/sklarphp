composer create-project --no-interaction --stability="dev" zendframework/skeleton-application menu
