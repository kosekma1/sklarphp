    'controllers' => array(
        'invokables' => array(
            'Application\Controller\Index' => 'Application\Controller\IndexController',
            'Application\Controller\Menu' => 'Application\Controller\MenuController'
        ),
    ),
