<?php
$email = 'jacob@example.com';
print "Send replies to: $email";