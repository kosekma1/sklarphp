<?php
print 'We\'ll each have a bowl of soup.';