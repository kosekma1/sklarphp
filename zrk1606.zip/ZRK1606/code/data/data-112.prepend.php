<?php

$birthday = 100;
$years_left = 50;
