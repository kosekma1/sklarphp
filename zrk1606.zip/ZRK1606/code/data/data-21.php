<?php
print 17 % 3;