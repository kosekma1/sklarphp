<?php
print 'Use a \\ to escape in a string';