<?php
$preparation = 'Braise';
$meat = 'Beef';
print "{$preparation}d $meat with Vegetables";