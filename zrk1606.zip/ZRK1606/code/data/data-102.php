<?php
print ucwords(strtolower('JOHN FRANKENHEIMER'));