<?php

$s = '$x = ' . file_get_contents(__DIR__ .'/data-100.txt') . ';';
