<?php

$_POST['zipcode'] = '   10040   ';
