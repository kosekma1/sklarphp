<?php
print 2 + 2;
print 17 - 3.5;
print 10 / 3;
print 6 * 9;