<?php
if ($_POST['email'] == 'president@whitehouse.gov') {
   print "Welcome, US President.";
}