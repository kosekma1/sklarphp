<?php

$_POST['comments'] = file_get_contents(__DIR__ . '/data-16.txt');
