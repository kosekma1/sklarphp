<?php $defaults['delivery'] = 'yes';
$defaults['size'] = 'medium';