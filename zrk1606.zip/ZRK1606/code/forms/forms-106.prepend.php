<?php $_SERVER['PHP_SELF'] = 'order.php';
