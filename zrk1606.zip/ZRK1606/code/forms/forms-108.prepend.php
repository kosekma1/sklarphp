<?php $_POST['order'] = 'blub';
$GLOBALS['sweets'] = array('beep' => 'toot');