<?php
$_POST['lunch'][] = 'chicken';
$_POST['lunch'][] = 'nest';
