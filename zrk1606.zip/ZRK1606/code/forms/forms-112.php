<?php
print '<input type="text" name="my_name" value="' .
      htmlentities($defaults['my_name']). '">';