<?php
if (isset($_POST['product_id'])) { print $_POST['product_id']; }
