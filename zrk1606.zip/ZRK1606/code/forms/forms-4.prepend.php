<?php
$_POST['order'] = 'alice';
$GLOBALS['sweets'] = array('alice','bob');