<?php print "PHP enabled"; ?>
