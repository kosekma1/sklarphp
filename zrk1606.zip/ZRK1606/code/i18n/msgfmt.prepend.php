<?php

include "msgcat.php";
