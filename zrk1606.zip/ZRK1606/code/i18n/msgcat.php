<?php
$messages = array();
$messages['en_US'] = array('FAVORITE_FOODS' => 'My favorite food is {0}',
                           'COOKIE' => 'cookie',
                           'SQUASH' => 'squash');
$messages['en_GB'] = array('FAVORITE_FOODS' => 'My favourite food is {0}',
                           'COOKIE' => 'biscuit',
                           'SQUASH' => 'marrow');
