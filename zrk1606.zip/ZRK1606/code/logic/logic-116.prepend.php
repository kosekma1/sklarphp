<?php

$age = 100;
$celsius_temp = 50;
$kelvin_temp = 12;

?>
