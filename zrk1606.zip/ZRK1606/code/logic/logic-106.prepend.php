<?php

$age = 10;
$meal = 'lunch';
$dessert = 'cookie';
