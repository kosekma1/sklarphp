<?php $new_messages = 17; ?>
