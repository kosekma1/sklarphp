<?php
if ($new_messages = 12) {
    print "It seems you now have twelve new messages.";
}
