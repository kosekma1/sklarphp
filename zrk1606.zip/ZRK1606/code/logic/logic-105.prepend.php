<?php $first_name = $last_name = 'Bob'; ?>
