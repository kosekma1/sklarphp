<?php $word = 'zip'; ?>
