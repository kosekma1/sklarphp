<?php
$price = $quantity = 5;