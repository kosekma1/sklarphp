<?php

$logged_in = false;
$new_messages = false;
$emergency = false;
