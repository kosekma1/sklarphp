<?php
if (12 == $new_messages) {
    print "You have twelve new messages.";
}
