<?php

$new_messages = 12;
$dinner = 'food';

?>
