<?php

assert($a < 0);
assert($b > 0);
