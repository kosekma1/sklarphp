<?php

$new_messages = 12;
$max_messages = 100;
$dinner = 'food';
