<?php
if (! strcasecmp($first_name,$last_name)) {
    print '$first_name and $last_name are equal.';
}