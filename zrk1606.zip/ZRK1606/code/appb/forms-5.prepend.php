<?php
$_POST = ['alice' => 'bob',
          'charlie' => [ 'david','edgar'],
          'frank' => [ 'george' => ['harry', 'ignatz'],
                       'julius' => ['karl', 'leonardo'] ] ];