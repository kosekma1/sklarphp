CREATE TABLE customers (
   customer_id INTEGER PRIMARY KEY,
   name VARCHAR(255),
   phone VARCHAR(32),
   favorite_dish_id INT
);
