<?php
$n = 1; $p = 2;
print "$n, $p\n";

$n++; $p *= 2;
print "$n, $p\n";

$n++; $p *= 2;
print "$n, $p\n";

$n++; $p *= 2;
print "$n, $p\n";

$n++; $p *= 2;
print "$n, $p\n";
