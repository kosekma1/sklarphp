<?php
die('This is: ' . __FILE__);
