<?php
if $logged_in) {
        print "Welcome, user.";
    }
?>