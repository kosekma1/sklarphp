<?php
print '<pre>';
var_dump($_POST);
print '</pre>';