<?php $price = $tax_rate = 0;
