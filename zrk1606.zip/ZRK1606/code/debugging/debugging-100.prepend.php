<?php 
$_POST = array('ham' => 'burger');
