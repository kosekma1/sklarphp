<?php $total_price = $price = $tax_rate = 0;
