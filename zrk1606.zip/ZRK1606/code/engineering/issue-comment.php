<?php
// MXH-26: URL-encode email address to prevent problems with +
$email = urlencode($email);