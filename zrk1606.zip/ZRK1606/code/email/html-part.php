<?php

$message->addPart(<<<_HTML_
<p>Dear James,</p>
<p>You should try this:</p>
<ul>
<li>puree 1 pound of chicken with two pounds of asparagus in the blender</li>
<li>drop small balls of the mixture into a deep fryer.</li>
</ul>

<p><em>Yummy!</em</p>

<p>Love,</p>
<p>Julia</p>

_HTML_
    // MIME type as second argument
    , "text/html");
