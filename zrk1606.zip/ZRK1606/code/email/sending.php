<?php

$mailer->send($message);