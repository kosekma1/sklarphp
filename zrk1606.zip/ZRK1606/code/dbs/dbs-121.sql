SELECT dish_name, price FROM dishes
