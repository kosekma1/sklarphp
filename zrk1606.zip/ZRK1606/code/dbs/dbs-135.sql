UPDATE dishes SET price = price * 2 WHERE dish_name LIKE '%chili%'
