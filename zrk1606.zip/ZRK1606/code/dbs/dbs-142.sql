DROP TABLE dishes
