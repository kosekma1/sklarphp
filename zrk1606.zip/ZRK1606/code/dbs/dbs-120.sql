SELECT column1[, column2, column3, ...] FROM tablename
