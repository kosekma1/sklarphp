SELECT dish_name, price FROM dishes ORDER BY dish_name LIMIT 10
