<?php 

require 'preamble.prepend.php';
$_POST['new_dish_name'] = 'blub';
$_POST['new_price'] = 12;
$_POST['is_spicy'] = 0;
