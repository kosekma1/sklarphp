INSERT INTO table (column1[, column2, column3, ...])
    VALUES (value1[, value2, value3, ...])
