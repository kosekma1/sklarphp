SELECT * FROM dishes
