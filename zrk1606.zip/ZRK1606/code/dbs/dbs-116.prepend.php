<?php 

require 'preamble.prepend.php';
$_POST['new_dish_name'] = 'blub';
