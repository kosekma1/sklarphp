INSERT INTO dishes (dish_id, dish_name, price, is_spicy)
    VALUES (1, 'Braised Sea Cucumber', 6.50, 0)
