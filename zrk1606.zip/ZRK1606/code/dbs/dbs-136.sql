DELETE FROM dishes WHERE dish_name LIKE '%Shrimp'
