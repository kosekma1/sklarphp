<?php 

require 'preamble.prepend.php';
$_POST['dish_search'] = 'x';
