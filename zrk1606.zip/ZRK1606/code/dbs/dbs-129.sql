SELECT dish_name FROM dishes ORDER BY price DESC, dish_name
