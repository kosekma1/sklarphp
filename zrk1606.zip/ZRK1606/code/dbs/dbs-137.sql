SELECT * FROM dishes WHERE dish_name LIKE '%50\% off%'
