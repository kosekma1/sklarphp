DELETE FROM tablename [WHERE where_clause]
