<?php

print $affectedRows;
