UPDATE dishes SET price = price * 2
