<?php
$db = new PDO('mysql:host=db.example.com;dbname=restaurant','penguin','top^hat');
