<?php
$vegetables = ['corn' => 'yellow', 'beet' => 'red', 'carrot' => 'orange'];

$dinner = [0 => 'Sweet Corn and Asparagus',
           1 => 'Lemon Chicken',
           2 => 'Braised Bamboo Fungus'];

$computers = ['trs-80' => 'Radio Shack', 2600 => 'Atari', 'Adam' => 'Coleco'];
