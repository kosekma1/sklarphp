<?php
unset($dishes['Roast Duck']);