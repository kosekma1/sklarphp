<?php var_dump($vegetables,$fruits);
