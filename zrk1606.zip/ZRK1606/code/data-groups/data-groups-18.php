<?php
$letters = array('A','B','C','D');
print implode('',$letters);