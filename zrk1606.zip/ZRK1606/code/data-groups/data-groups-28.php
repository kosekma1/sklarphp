<?php
$students = [ 'James D. McCawley' => [ 'grade' => 'A+','id' => 271231 ],
              'Buwei Yang Chao' => [ 'grade' => 'A', 'id' => 818211] ];