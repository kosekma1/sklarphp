<?php
page_header( );
print "Welcome, $user";
print "</body></html>";