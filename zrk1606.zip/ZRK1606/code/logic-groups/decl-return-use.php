<?php
restaurant_check(100,7,20);