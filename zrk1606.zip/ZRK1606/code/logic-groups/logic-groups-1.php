<?php
page_header2('cc00cc');