<?php
include __DIR__ . '/decl-return.php';
