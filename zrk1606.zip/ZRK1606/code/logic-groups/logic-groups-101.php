<?php
$number_to_display = number_format(320853904);
print "The population of the US is about: $number_to_display";
